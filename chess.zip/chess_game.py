# chess_game.py

import pygame
import sys

# Initialize Pygame
pygame.init()

# Constants
WIDTH, HEIGHT = 800, 800
ROWS, COLS = 8, 8
SQUARE_SIZE = WIDTH // COLS

# Colors
BLUE = (0, 0, 255)
RED = (255, 0, 0)
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GRAY = (128, 128, 128)

# Load piece images and scale them
PIECES = {
    'bR': pygame.transform.scale(pygame.image.load('assets/bR.png'), (SQUARE_SIZE, SQUARE_SIZE)),
    'bN': pygame.transform.scale(pygame.image.load('assets/bN.png'), (SQUARE_SIZE, SQUARE_SIZE)),
    'bB': pygame.transform.scale(pygame.image.load('assets/bB.png'), (SQUARE_SIZE, SQUARE_SIZE)),
    'bQ': pygame.transform.scale(pygame.image.load('assets/bQ.png'), (SQUARE_SIZE, SQUARE_SIZE)),
    'bK': pygame.transform.scale(pygame.image.load('assets/bK.png'), (SQUARE_SIZE, SQUARE_SIZE)),
    'bP': pygame.transform.scale(pygame.image.load('assets/bP.png'), (SQUARE_SIZE, SQUARE_SIZE)),
    'wR': pygame.transform.scale(pygame.image.load('assets/wR.png'), (SQUARE_SIZE, SQUARE_SIZE)),
    'wN': pygame.transform.scale(pygame.image.load('assets/wN.png'), (SQUARE_SIZE, SQUARE_SIZE)),
    'wB': pygame.transform.scale(pygame.image.load('assets/wB.png'), (SQUARE_SIZE, SQUARE_SIZE)),
    'wQ': pygame.transform.scale(pygame.image.load('assets/wQ.png'), (SQUARE_SIZE, SQUARE_SIZE)),
    'wK': pygame.transform.scale(pygame.image.load('assets/wK.png'), (SQUARE_SIZE, SQUARE_SIZE)),
    'wP': pygame.transform.scale(pygame.image.load('assets/wP.png'), (SQUARE_SIZE, SQUARE_SIZE))
}

# Load texture images for the board squares and scale them
LIGHT_SQUARE_TEXTURE = pygame.transform.scale(pygame.image.load('assets/light_square.png'), (SQUARE_SIZE, SQUARE_SIZE))
DARK_SQUARE_TEXTURE = pygame.transform.scale(pygame.image.load('assets/dark_square.png'), (SQUARE_SIZE, SQUARE_SIZE))

# Initialize screen
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption('Chess')

# Font
font = pygame.font.SysFont('Arial', 36)

# Initial board state
initial_board = [
    ['bR', 'bN', 'bB', 'bQ', 'bK', 'bB', 'bN', 'bR'],
    ['bP', 'bP', 'bP', 'bP', 'bP', 'bP', 'bP', 'bP'],
    [None, None, None, None, None, None, None, None],
    [None, None, None, None, None, None, None, None],
    [None, None, None, None, None, None, None, None],
    [None, None, None, None, None, None, None, None],
    ['wP', 'wP', 'wP', 'wP', 'wP', 'wP', 'wP', 'wP'],
    ['wR', 'wN', 'wB', 'wQ', 'wK', 'wB', 'wN', 'wR']
]

board = [row[:] for row in initial_board]
selected_piece = None
selected_pos = None
turn = 'w'
game_over = False
winner = None

def draw_board():
    for row in range(ROWS):
        for col in range(COLS):
            if (row + col) % 2 == 0:
                texture = LIGHT_SQUARE_TEXTURE
            else:
                texture = DARK_SQUARE_TEXTURE
            screen.blit(texture, (col * SQUARE_SIZE, row * SQUARE_SIZE))

def draw_pieces():
    for row in range(ROWS):
        for col in range(COLS):
            piece = board[row][col]
            if piece:
                screen.blit(PIECES[piece], (col * SQUARE_SIZE, row * SQUARE_SIZE))

def draw_highlighted_cell(pos):
    if pos:
        pygame.draw.rect(screen, BLUE, (pos[1] * SQUARE_SIZE, pos[0] * SQUARE_SIZE, SQUARE_SIZE, SQUARE_SIZE), 5)

def draw_possible_moves(pos):
    if pos:
        piece = board[pos[0]][pos[1]]
        if piece:
            moves = get_possible_moves(piece, pos)
            for move in moves:
                pygame.draw.rect(screen, RED, (move[1] * SQUARE_SIZE, move[0] * SQUARE_SIZE, SQUARE_SIZE, SQUARE_SIZE), 5)

def get_possible_moves(piece, pos):
    moves = []
    if piece[1] == 'P':
        moves = get_pawn_moves(piece, pos)
    elif piece[1] == 'R':
        moves = get_rook_moves(piece, pos)
    elif piece[1] == 'N':
        moves = get_knight_moves(piece, pos)
    elif piece[1] == 'B':
        moves = get_bishop_moves(piece, pos)
    elif piece[1] == 'Q':
        moves = get_queen_moves(piece, pos)
    elif piece[1] == 'K':
        moves = get_king_moves(piece, pos)
    return moves

def get_pawn_moves(piece, pos):
    moves = []
    direction = -1 if piece[0] == 'w' else 1
    start_row = 6 if piece[0] == 'w' else 1
    if 0 <= pos[0] + direction < ROWS and board[pos[0] + direction][pos[1]] is None:
        moves.append((pos[0] + direction, pos[1]))
        if pos[0] == start_row and board[pos[0] + 2 * direction][pos[1]] is None:
            moves.append((pos[0] + 2 * direction, pos[1]))
    if pos[1] - 1 >= 0 and 0 <= pos[0] + direction < ROWS and board[pos[0] + direction][pos[1] - 1] and board[pos[0] + direction][pos[1] - 1][0] != piece[0]:
        moves.append((pos[0] + direction, pos[1] - 1))
    if pos[1] + 1 < COLS and 0 <= pos[0] + direction < ROWS and board[pos[0] + direction][pos[1] + 1] and board[pos[0] + direction][pos[1] + 1][0] != piece[0]:
        moves.append((pos[0] + direction, pos[1] + 1))
    return moves

def get_rook_moves(piece, pos):
    moves = []
    directions = [(-1, 0), (1, 0), (0, -1), (0, 1)]
    for direction in directions:
        for i in range(1, ROWS):
            new_row = pos[0] + i * direction[0]
            new_col = pos[1] + i * direction[1]
            if 0 <= new_row < ROWS and 0 <= new_col < COLS:
                if board[new_row][new_col] is None:
                    moves.append((new_row, new_col))
                elif board[new_row][new_col][0] != piece[0]:
                    moves.append((new_row, new_col))
                    break
                else:
                    break
            else:
                break
    return moves

def get_knight_moves(piece, pos):
    moves = []
    knight_moves = [(-2, -1), (-1, -2), (1, -2), (2, -1), (2, 1), (1, 2), (-1, 2), (-2, 1)]
    for move in knight_moves:
        new_row, new_col = pos[0] + move[0], pos[1] + move[1]
        if 0 <= new_row < ROWS and 0 <= new_col < COLS:
            if board[new_row][new_col] is None or board[new_row][new_col][0] != piece[0]:
                moves.append((new_row, new_col))
    return moves

def get_bishop_moves(piece, pos):
    moves = []
    directions = [(-1, -1), (-1, 1), (1, -1), (1, 1)]
    for direction in directions:
        for i in range(1, ROWS):
            new_row = pos[0] + i * direction[0]
            new_col = pos[1] + i * direction[1]
            if 0 <= new_row < ROWS and 0 <= new_col < COLS:
                if board[new_row][new_col] is None:
                    moves.append((new_row, new_col))
                elif board[new_row][new_col][0] != piece[0]:
                    moves.append((new_row, new_col))
                    break
                else:
                    break
            else:
                break
    return moves

def get_queen_moves(piece, pos):
    return get_rook_moves(piece, pos) + get_bishop_moves(piece, pos)

def get_king_moves(piece, pos):
    moves = []
    king_moves = [(-1, -1), (-1, 0), (-1, 1), (0, -1), (0, 1), (1, -1), (1, 0), (1, 1)]
    for move in king_moves:
        new_row, new_col = pos[0] + move[0], pos[1] + move[1]
        if 0 <= new_row < ROWS and 0 <= new_col < COLS:
            if board[new_row][new_col] is None or board[new_row][new_col][0] != piece[0]:
                moves.append((new_row, new_col))
    return moves

def move_piece(start_pos, end_pos):
    global turn, game_over, winner
    piece = board[start_pos[0]][start_pos[1]]
    if end_pos in get_possible_moves(piece, start_pos):
        board[end_pos[0]][end_pos[1]] = piece
        board[start_pos[0]][start_pos[1]] = None
        turn = 'b' if turn == 'w' else 'w'
        if is_in_check(board, 'w'):
            if is_checkmate(board, 'w'):
                game_over = True
                winner = 'Black'
        elif is_in_check(board, 'b'):
            if is_checkmate(board, 'b'):
                game_over = True
                winner = 'White'

def is_in_check(board, color):
    king_pos = None
    for row in range(ROWS):
        for col in range(COLS):
            if board[row][col] == color + 'K':
                king_pos = (row, col)
                break
    if king_pos is None:
        return False

    for row in range(ROWS):
        for col in range(COLS):
            if board[row][col] and board[row][col][0] != color:
                if king_pos in get_possible_moves(board[row][col], (row, col)):
                    return True
    return False

def is_checkmate(board, color):
    for row in range(ROWS):
        for col in range(COLS):
            if board[row][col] and board[row][col][0] == color:
                for move in get_possible_moves(board[row][col], (row, col)):
                    temp_board = [row[:] for row in board]
                    temp_board[move[0]][move[1]] = temp_board[row][col]
                    temp_board[row][col] = None
                    if not is_in_check(temp_board, color):
                        return False
    return True

def reset_game():
    global board, selected_piece, selected_pos, turn, game_over, winner
    board = [row[:] for row in initial_board]
    selected_piece = None
    selected_pos = None
    turn = 'w'
    game_over = False
    winner = None

def draw_game_over():
    screen.fill(GRAY)
    text = font.render(f"Game Over! {winner} wins!", True, WHITE)
    text_rect = text.get_rect(center=(WIDTH // 2, HEIGHT // 2 - 50))
    screen.blit(text, text_rect)
    
    button_text = font.render("Restart", True, WHITE)
    button_rect = button_text.get_rect(center=(WIDTH // 2, HEIGHT // 2 + 50))
    pygame.draw.rect(screen, BLACK, button_rect.inflate(20, 10))
    screen.blit(button_text, button_rect)
    
    return button_rect

def main():
    global selected_piece, selected_pos
    clock = pygame.time.Clock()
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                mouse_pos = pygame.mouse.get_pos()
                if game_over:
                    button_rect = draw_game_over()
                    if button_rect.collidepoint(mouse_pos):
                        reset_game()
                else:
                    row, col = mouse_pos[1] // SQUARE_SIZE, mouse_pos[0] // SQUARE_SIZE
                    if selected_piece:
                        move_piece(selected_pos, (row, col))
                        selected_piece = None
                        selected_pos = None
                    else:
                        if board[row][col] and board[row][col][0] == turn:
                            selected_piece = board[row][col]
                            selected_pos = (row, col)

        if game_over:
            draw_game_over()
        else:
            draw_board()
            draw_pieces()
            draw_highlighted_cell(selected_pos)
            draw_possible_moves(selected_pos)
        
        pygame.display.flip()
        clock.tick(60)

if __name__ == "__main__":
    main()
